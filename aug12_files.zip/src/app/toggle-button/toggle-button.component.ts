import { Component} from '@angular/core';
import { D3BubbleChartComponent } from '../d3-bubble-chart/d3-bubble-chart.component';

@Component({
  providers:[D3BubbleChartComponent],
  selector: 'toggle-button',
  templateUrl: './toggle-button.component.html',
  styleUrls: ['./toggle-button.component.css']
})
export class ToggleButtonComponent  {
  constructor(private d3chart: D3BubbleChartComponent){}

  changed(toggle: any){
    console.log("Toggled:",toggle)
    this.d3chart.buttonToggled(toggle);
  };


}
