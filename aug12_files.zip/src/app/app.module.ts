import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { D3BubbleChartComponent } from './d3-bubble-chart/d3-bubble-chart.component';
import { ToggleButtonComponent } from './toggle-button/toggle-button.component';


@NgModule({
  declarations: [
    AppComponent,
    D3BubbleChartComponent,
    ToggleButtonComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
