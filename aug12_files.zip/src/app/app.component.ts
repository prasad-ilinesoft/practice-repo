import { Component, ViewChild } from '@angular/core';
import { CSVRecord } from './CSVRecord';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Analystics-dashboard1';

  public application:any='';
  public variable:any='';
  public table:any='';
  public variableText:any='';
  public records: any[] = [];
  public apiRecords: any[] = [];
  public headers: any[] = ["Application", "Table", "Variable"];

  @ViewChild('csvReader') csvReader: any;
  uploadListener($event: any): void {
    let text = [];
    this.variableText = '';
    let files = $event.srcElement.files;
    if (this.isValidCSVFile(files[0])) {
      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);
      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);
        this.records = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
        console.log("this.records",this.records)

      };
      reader.onerror = function () {
        console.log('error is occured while reading file!');
      };
    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }
  getApiDataRecordsArray(apiJson: any){
    let apiArr = [];
    for (let i = 0; i < apiJson.length; i++) {
        let csvRecord: CSVRecord = new CSVRecord();
        if(apiJson[i].application !== undefined){
          csvRecord["application"] = apiJson[i].application;
        }
        csvRecord.table = apiJson[i].table;
        csvRecord.variable = apiJson[i].variable;
        csvRecord.variableDefinition = apiJson[i].variableDefinition;
        csvRecord.derived = apiJson[i].derived;
        csvRecord.logic = apiJson[i].logic;
        csvRecord.key = apiJson[i].key;
        csvRecord.rangeValue = apiJson[i].rangeValue;
        csvRecord.businessRuleCheck = apiJson[i].businessRuleCheck;
         apiArr.push(csvRecord);
    }
    return apiArr;
  }
  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let csvArr = [];
    console.log("csvRecordsArray",csvRecordsArray)
    for (let i = 3; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == headerLength) {
        let csvRecord: CSVRecord = new CSVRecord();
        csvRecord.application = curruntRecord[1].trim();
        csvRecord.table = curruntRecord[2].trim();
        csvRecord.variable = curruntRecord[3].trim();
        csvRecord.variableDefinition = curruntRecord[4].trim();
        csvRecord.derived = curruntRecord[5].trim();
        csvRecord.logic = curruntRecord[6].trim();
        csvRecord.key = curruntRecord[7].trim();
        csvRecord.rangeValue = curruntRecord[8].trim();
        csvRecord.businessRuleCheck = curruntRecord[9].trim();
        csvArr.push(csvRecord);
      }
    }
    return csvArr;
  }
  isValidCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }
  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }
  fileReset() {
    this.csvReader.nativeElement.value = "";
    this.records = [];
  }
  onSearch(event: any){
    let searchTxt = event.target.value;
    console.log(searchTxt);

    let apiJson = [
      {
        "application": "LaaS-UI",
        "table": "Participants",
        "variable": "ParticipantId",
        "variable definition derived": "Unique ID",
        "logic": "N",
        "key": "Auto increment",
        "range value": "pk",
        "busines rul check": "0 to 4294967295"
      },
      {
        "application": "LaaS-UI",
        "table": "Participants",
        "variable": "FirstName",
        "variable definition derived": "First name of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI",
        "table": "Participants-1",
        "variable": "LastName",
        "variable definition derived": "Last name of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "Participants",
        "variable": "MI",
        "variable definition derived": "Middle name of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "Participants",
        "variable": "Employer",
        "variable definition derived": "Employer of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "Particpants",
        "variable": "BalanceTransfer",
        "variable definition derived": "If customer wants to add balance transfer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "Particpants",
        "variable": "AddAuthorizedUser",
        "variable definition derived": "If customer wants to add uthorized user to their account",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI",
        "table": "Particpants",
        "variable": "IsInSchool",
        "variable definition derived": "Check if customer is in school",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI",
        "table": "Particpants",
        "variable": "RelationshipId",
        "variable definition derived": "customer relation with cosigner",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI",
        "table": "Applications",
        "variable": "SoftPullConsent",
        "variable definition derived": "Consent of customer for prequalify",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "ApplicationLoans",
        "variable": "Address",
        "variable definition derived": "Complte address of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "ApplicationLoans",
        "variable": "IsAddressManual",
        "variable definition derived": "check if customer entered address manually",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "ApplicationLoans",
        "variable": "StreetAddress",
        "variable definition derived": "street address of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "ApplicationLoans",
        "variable": "Unit",
        "variable definition derived": "Unit number of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "ApplicationLoans",
        "variable": "City",
        "variable definition derived": "City of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "ApplicationLoans",
        "variable": "State",
        "variable definition derived": "State of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "ApplicationLoans",
        "variable": "ZipCode",
        "variable definition derived": "Zip code of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI(Credit card flow)",
        "table": "ApplicationLoans",
        "variable": "Country",
        "variable definition derived": "Country of customer",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI",
        "table": "ApplicationLoans",
        "variable": "LoanTypeDeferalPrivate",
        "variable definition derived": "Loan type provided by customer (private/federal/unsure)",
        "logic": "N",
        "key": "User input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS-UI",
        "table": "Documents",
        "variable": "DocumentId",
        "variable definition derived": "file inputted by user",
        "logic": "N",
        "key": "User Input",
        "range value": "pk",
        "busines rul check": "0 to 4294967295"
      },
      {
        "application": "LaaS-UI",
        "table": "Documents",
        "variable": "URL",
        "variable definition derived": "Document stored location",
        "logic": "N",
        "key": "System input",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS_API",
        "table": "Participants",
        "variable": "CreatedOn",
        "variable definition derived": "current date and Time",
        "logic": "Y",
        "key": "DB defalut Date&Time value",
        "range value": "",
        "busines rul check": ""
      },
      {
        "application": "LaaS_API",
        "table": "Participants",
        "variable": "UserId",
        "variable definition derived": "UserId based from current  session",
        "logic": "Y",
        "key": "(req.session && req.session.passport && req.session.passport.user) ? req.session.passport.user.UserId : req.user.userid",
        "range value": "fk",
        "busines rul check": "0"
      },
      {
        "application": "LaaS_API",
        "table": "Participants",
        "variable": "DecisionId",
        "variable definition derived": "DecisionId",
        "logic": "N",
        "key": "Req.Body",
        "range value": "fk",
        "busines rul check": "1"
      },
      {
        "application": "LaaS_API",
        "table": "Participants",
        "variable": "CitizenshipId",
        "variable definition derived": "CitizenshipId",
        "logic": "N",
        "key": "Req.Body",
        "range value": "fk",
        "busines rul check": "0"
      }
    ];

    this.apiRecords = this.getApiDataRecordsArray(apiJson);
    console.log("apiRecords",this.apiRecords);
  }

}
