import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import * as d3 from 'd3';
declare var createD3BubbleChart: any;
declare var generateSvg: any;

@Component({
  selector: 'app-d3-bubble-chart',
  templateUrl: './d3-bubble-chart.component.html',
  styleUrls: ['./d3-bubble-chart.component.css']
})


export class D3BubbleChartComponent implements OnInit {


  apiJsonArr: any = [];
  headers: any[] = [];
  constructor(private appComp: AppComponent) { }

  ngOnInit(): void {
  }



  buttonToggled(toggle: any) {
    console.log("In buttonToggled..");
    if (toggle) {

      d3.select(".chart_container").style("visibility", "visible");


      this.headers = this.appComp.headers;
      this.apiJsonArr = this.appComp.apiRecords;

      var applicationChildren = [];
      var tableChildren = [];
      var columnChildren = [];
      for (var i = 0; i < this.apiJsonArr.length; i++) {
        let obj = this.apiJsonArr[i];
        this.ifAlreadyExist(applicationChildren, obj);
      }
      var finalObject = {};
      finalObject['name'] = "Application",

      finalObject['children'] = applicationChildren;
      generateSvg(d3);
      createD3BubbleChart(finalObject, d3);
    } else {
      d3.select(".chart_container").style("visibility", "hidden");
    }
  }


  ifAlreadyExist(applicationChildren, obj) {
    var tableChildren = [];
    var columnChildren = [];
    var isExisted = false;
    var isTableExisted = false;
    for (var i = 0; i < applicationChildren.length; i++) {
      var eObj = applicationChildren[i];
      if (eObj["name"] === obj[this.headers[0].toLowerCase()]) {
        isExisted = true;
        tableChildren = eObj["children"];
        for (var j = 0; i < tableChildren.length; j++) {
          var tObje = tableChildren[j];
          if (tObje === undefined) {
            break;
          }
          if (tObje["name"] === obj[this.headers[1].toLowerCase()]) {
            columnChildren = tObje["children"];
            var desideAddColumn = true;
            for (var m = 0; m < columnChildren.length; m++) {
              var columnDetails = columnChildren[m];
              if (columnDetails.name === obj[this.headers[2].toLowerCase()]) {
                desideAddColumn = false;
              }
            }
            if (desideAddColumn) {
              var columnData = {};
              columnData['name'] = obj[this.headers[2].toLowerCase()];
              columnData['children'] = this.addVaribleDefination(obj);
              columnChildren.push(columnData);
            }
          } else {
            var isAlreadyThere = 0;
            for (var k = 0; i < tableChildren.length; k++) {
              var tempObj = tableChildren[k];
              if (tempObj != undefined && tempObj["name"] === obj[this.headers[1].toLowerCase()]) {
                isAlreadyThere = 1;
                break;
              }
              if (tableChildren.length === k)
                break;

            }
            if (isAlreadyThere === 0) {
              var tempObj = tableChildren[j];
              var newcolumnChildrenA = [];
              var newcolumnChildren = {};
              newcolumnChildren['name'] = obj[this.headers[2].toLowerCase()];
              newcolumnChildren['children'] = this.addVaribleDefination(obj);
              newcolumnChildrenA.push(newcolumnChildren);
              var newtableChildrenA = [];
              var newtableChildren = {};
              newtableChildren['name'] = obj[this.headers[1].toLowerCase()];
              newtableChildren['children'] = newcolumnChildrenA;
              tableChildren.push(newtableChildren);
            }
          }
        }
      }
    }
    if (applicationChildren.length === 0 || !isExisted) {
      this.addNewApp(applicationChildren, obj);
    }
  }

  addNewApp(applicationChildren, obj) {
    let columnChildrenA = [];
    let columnChildren = {};
    console.log("this.headers[2].toLowerCase():",this.headers[2].toLowerCase())
    columnChildren['name'] = obj[this.headers[2].toLowerCase()];
    columnChildren['children'] = this.addVaribleDefination(obj);//["d_variable"];
    columnChildrenA.push(columnChildren);
    let tableChildrenA = [];
    let tableChildren = {};
    tableChildren['name'] = obj[this.headers[1].toLowerCase()];
    tableChildren['children'] = columnChildrenA;
    tableChildrenA.push(tableChildren);
    let appChildren = {};
    appChildren['name'] = obj[this.headers[0].toLowerCase()];
    appChildren['children'] = tableChildrenA;
    applicationChildren.push(appChildren);
  }

  addVaribleDefination(obj) {
    let columnChildrenA = [];
    let columnChildren = {};
    //columnChildren['name'] =  obj["d_variable_definition"]+':d_variable_definition';
    //columnChildrenA.push(columnChildren);
    /*columnChildren = {};	
    columnChildren.name =  obj["d_derived"]+':d_derived';
    columnChildrenA.push(columnChildren);
    
    columnChildren = {};	
    columnChildren.name =  obj["d_logic"]+':d_logic';
    columnChildrenA.push(columnChildren);
    
    columnChildren = {};	
    columnChildren.name =  obj["d_Range_Value"]+':d_Range_Value';
    columnChildrenA.push(columnChildren);
    
    columnChildren = {};	
    columnChildren.name =  obj["s_sor"]+':s_sor';
    columnChildrenA.push(columnChildren);
    
    columnChildren = {};	
    columnChildren.name =  obj["d_datatype_check"]+':d_datatype_check';
    columnChildrenA.push(columnChildren);
    
    columnChildren = {};	
    columnChildren.name =  obj["d_business_rule_check"]+':d_business_rule_check';
    columnChildrenA.push(columnChildren);
    */
    return columnChildrenA
  }

}


