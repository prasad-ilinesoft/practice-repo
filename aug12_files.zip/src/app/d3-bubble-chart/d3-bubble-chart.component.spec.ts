import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { D3BubbleChartComponent } from './d3-bubble-chart.component';

describe('D3BubbleChartComponent', () => {
  let component: D3BubbleChartComponent;
  let fixture: ComponentFixture<D3BubbleChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ D3BubbleChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(D3BubbleChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
