export class CSVRecord {
    public id: any;
    public hovered: boolean;
    public application: any;
    public table: any;
    public variable: any;
    public variableDefinition: any;
    public derived: any;
    public logic: any;     
    public key: any; 
    public rangeValue: any; 
    public businessRuleCheck: any;     
  }